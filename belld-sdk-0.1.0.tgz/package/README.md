# @belld/sdk v0

BellD Product 的 Node.js 22+ runtime SDK，零外部執行期依賴。只透過 runner 提供的本機 capability endpoint 呼叫能力，不提供 streaming 或外部 Bridge client。

## 安裝與匯入

在本 monorepo 根目錄執行：

```sh
pnpm install
pnpm sdk:gen
pnpm --filter @belld/sdk build
```

Workspace Product 可在自己的 package.json 宣告 `"@belld/sdk": "workspace:*"`，並將其目錄納入 workspace。SDK 匯入方式：

```js
import { belld, BellDCapabilityError, createFakeBellD } from '@belld/sdk';
```

獨立 Product image 不需要 npm install：將 `sdk/typescript/package.json` 和建好的 `sdk/typescript/dist/` 複製到 Product 的 `node_modules/@belld/sdk/`。打包時排除 `*.test.*`；套件的 `files` 設定已排除這些測試產物。請在外部建置完成後再包入 image。套件目前由 workspace 交付，這些指令不假設已發佈 npm。

## 必須綁定 Consumer 請求

Runner 每次轉送 Consumer 請求時注入並覆寫 `BellD-Execution-Token` header。所有真實 SDK 呼叫必須位於 `belld.withRequest(req, fn)` 內；SDK 用 AsyncLocalStorage 隔離並行請求，轉送 token 作為 Bearer。`req` 只須有 `headers`（Node header 物件或具有 `get(name)` 的 Headers 物件）。不要自行建立、儲存或共用 execution token。

沒有請求脈絡、缺少 token 或多值 token 時，呼叫直接拋 `BellDCapabilityError`，`code === 'unauthenticated'`，不打 endpoint。`withRequest` 回傳 callback 的原值／Promise。

Runner 設定 `BELLD_CAPABILITY_ENDPOINT=unix:///absolute/path/proxy.sock`。SDK 只接受 unix socket；未設定或 `vsock://` 會明確報錯。Kata 下 runner 在 VM 內將 host vsock 橋接成 `unix:///tmp/belld-capability/proxy.sock`；Product 與 start script 不需要 socat。

## 完整可執行 ai.generate Product

將以下存為 `server.mjs`，依上方方式放入 SDK，執行 `node server.mjs`。正式執行由 runner 注入 endpoint 和請求 header；本機無 runner 時可用下方 fake 寫測試，或執行 repo E2E。

```js
import http from 'node:http';
import { belld, BellDCapabilityError } from '@belld/sdk';

const server = http.createServer((req, res) => {
  if (req.url === '/health') { res.end('ok'); return; }
  const chunks = [];
  req.on('data', chunk => chunks.push(chunk));
  req.on('end', async () => {
    try {
      const prompt = Buffer.concat(chunks).toString('utf8') || decodeURIComponent((req.url ?? '/').slice(1));
      const output = await belld.withRequest(req, () => belld.ai.generate({
        model_kind: 'text',
        max_tokens: 100,
        input: { messages: [{ role: 'user', content: prompt }] },
      }));
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify(output));
    } catch (error) {
      if (error instanceof BellDCapabilityError) {
        res.writeHead(error.status ?? 503, { 'content-type': 'application/problem+json' });
        res.end(JSON.stringify(error.toProblem()));
      } else {
        res.writeHead(500); res.end('Product invocation failed.');
      }
    }
  });
});
server.listen(Number(process.env.PORT ?? 8080), '127.0.0.1', () => {
  console.log(JSON.stringify({ port: server.address().port }));
});
```

`model_kind` 只可為 `text` 或 `embedding`；`max_tokens` 是正整數。單一 options 物件包含 per-call request 欄位及必填 `input`（非空 JSON payload）。不傳 `id` / `action`，SDK 從方法推導路徑。SDK 不轉換 prompt、不編造 output schema。回傳值是 output JSON 本身，型別為 `Promise<unknown>`；可寫 `belld.ai.generate<MyOutput>(options)` 自行斷言，這不會驗證輸出。

Storage 方法為 `belld.storage.object.read/write/delete/list({ key, bytes?, input })`。`key` 是 `/` 開頭、不含 `..` 或 NUL 的路徑；`bytes` 若有提供須為非負整數。整個 HTTP body 上限 8 MiB；超過 64 KB 的 input 由 proxy 透明處理 evidence。數值範圍與路徑限制由 proxy／目錄驗證，TypeScript 的 number/string 本身不保證這些限制。

## storage.object v0 範例

在 `withRequest` 的 callback 內使用以下流程。Product key 不含 workspace／product 的平台前綴；contract 的 prefix／actions／大小上限仍適用。

```ts
const bytes = Buffer.from([0, 255, 128, 1]);
await belld.storage.object.write({
  key: '/data/example.bin', bytes: bytes.length, // write 必填，指解碼後的 bytes
  input: { content_base64: bytes.toString('base64'), content_type: 'application/octet-stream' },
});
const read = await belld.storage.object.read<{
  key: string; found: boolean; content_base64?: string; sha256?: string;
}>({ key: '/data/example.bin', input: {} });
if (read.found) Buffer.from(read.content_base64!, 'base64');
const page = await belld.storage.object.list<{ objects: { key: string; size_bytes: number; updated_at: string }[]; next_cursor?: string }>({
  key: '/data/', input: { limit: 10 }, // prefix 必以 / 結尾；limit 1..100
});
if (page.next_cursor) await belld.storage.object.list({ key: '/data/', input: { limit: 10, cursor: page.next_cursor } });
await belld.storage.object.delete({ key: '/data/example.bin', input: {} });
// 再 read 會得到 { key: '/data/example.bin', found: false }。
```

物件上限 1 MiB；contract 可收窄。`content_type` 可省略，若提供須為 `type/subtype` 且最多 128 字元。key 不得含連續 `//`，最多 1024 UTF-8 bytes。input／output 超過 64 KB 由既有通道透明使用 evidence，binary 一律 base64，SDK 方法簽章不變。read 未命中計 0 bytes；write／read 按內容 bytes 計量，delete／list 每次計 1 byte。此用量不是物件佔用量的持續計費。

## 錯誤與重試

非 2xx 解析為 `BellDCapabilityError`，保留 `code`、`reason`、`correlation_id`、`status`。`toProblem()` 回傳完整收到的 problem 欄位，可直接轉交 Consumer，包含 title/detail/instance。不要把 token 或完整請求寫入 log。

只有 `runner_evidence_write_failed` 與 `runner_control_plane_server_error` 兩種 reason 會自動重試；判斷不依 HTTP status（控制面 5xx 排除 501 由 proxy 映射為後者，501 則為 `runner_control_plane_unexpected_status`）。`runner_control_plane_unreachable`、`provider_unavailable`、完整性錯誤與其餘 reason 均不重試；403 denied、404 not_found、429 usage_denied／限流、400 bad_request 不重試。連線失敗、逾時或 HTML／無效 problem body 映射 `code: 'unavailable'`，reason 為 undefined，不重試。

重試依序退避 1／3／7／15 秒，最多 4 次重試（共 5 次嘗試），整串嘗試原樣重送同一份 body 與冪等鍵。`timeoutMs` 是一次邏輯 capability 呼叫的總 deadline，從第一次嘗試起包含所有 HTTP 等待與退避，預設仍為 30 秒；每次 HTTP 嘗試只取得當下剩餘時間。若剩餘時間小於或等於下一段退避，就不等待、不送請求，直接拋出最後的錯誤；退避後 deadline 已耗盡也直接拋出。需要調整時可用 `createBellD({ timeoutMs: 5000 })`，它與 `belld` 同介面。每次重試可能觸發新的 invocation 與 provider 計費，因此即使 deadline 尚有餘裕也不超過五次嘗試。

## 不需 endpoint 的測試

```js
import assert from 'node:assert/strict';
import { createFakeBellD, BellDCapabilityError } from '@belld/sdk';

const client = createFakeBellD({
  'ai.generate/generate': { response: 'hello from fake' },
  'storage.object/write': {
    error: new BellDCapabilityError({ code: 'forbidden', reason: 'permission_denied', status: 403, correlation_id: 'evt_test' }),
  },
});
assert.equal(await client.ai.generate({ model_kind: 'text', max_tokens: 100, input: { messages: [{ role: 'user', content: 'hello' }] } }), 'hello from fake');
await assert.rejects(client.storage.object.write({ key: '/a', bytes: 1, input: { value: 'a' } }), { code: 'forbidden' });
```

Fake 與真 client 同介面，可注入 Product 函式；`withRequest` 直接執行 callback，無需 token，不做重試。每個方法以 `capability_id/action` 預設回應或錯誤；未設定的方法拋 `not_found`，不會靜默成功。

## 用 BellD capability 取代 provider SDK

Product 內不得出現 provider SDK、API key 或具體 model 名稱。刪除 provider client、credential env 讀取及自行 retry/budget/audit 邏輯，改以 `withRequest` + `ai.generate` 呼叫。Product 只指定 model kind、token 上限與 JSON input；具體 model、憑證、授權、budget、audit 由 BellD 管理。不要把 `prompt` 或 storage `body` 當成 SDK options；payload 統一叫 `input`。

## Repo 整合測試

```sh
pnpm exec vitest run --project unit tools/e2e/src/ai-generate-e2e.test.ts --testTimeout 120000
RUNNER_E2E=1 RUNNER_E2E_URL=http://127.0.0.1:18081 RUNNER_E2E_S3_BUCKET=belld-dev pnpm exec vitest run --project unit tools/e2e/src/ai-generate-e2e.test.ts --testTimeout 120000
```

第一條驗證 in-process 成功、budget denied 與 secret guard。第二條需要啟動 runner 及 S3 evidence storage，並設定 runner 的 Control API callback 指向測試服務（預設 port 3001）。它會建置 ai-echo Docker image，用 FakeProviderAdapter 驗證 image 內的 SDK 成功回應與 budget denied，不需要 provider key。另有真 provider 案例，需要 `BELLD_E2E_AI_PROVIDER_KEY` 與 runner log 設定；缺 key 時只有該案例會 skip。Runner 未啟用時，Docker 案例會 skip。

方法與 options 由官方目錄產生；修改 SDK 產生器後跑 `pnpm sdk:gen`，`pnpm sdk:check` 會在 drift 時失敗。SDK major 僅在目錄 breaking 時升版。

SDK 會為每次邏輯 capability 呼叫附上獨立的 per-call 冪等鍵；同次呼叫的所有重試沿用同一顆鍵，控制面重放首次成功回應，避免重試重複計費。
